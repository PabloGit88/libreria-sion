<?php

namespace Odiseo\Bundle\AppBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OdiseoAppBundle extends Bundle
{
}
